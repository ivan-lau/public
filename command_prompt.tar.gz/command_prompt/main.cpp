#include <fmt/format.h>
#include <chrono>
#include <thread>
#include <csignal>
#include <iostream>
#include <string>
#include <optional>
#include <termios.h>
#include <unistd.h>

// Flag indicating whether the SIGINT signal was received.
volatile bool sigint_received = false;

// Signal handler for SIGINT (Ctrl+C).
void handle_sigint(int) {
  sigint_received = true;
}

void disable_term() {
  // Disable printing of control characters.
  termios term;
  tcgetattr(STDIN_FILENO, &term);
  term.c_lflag &= ~(ICANON | ECHO);
  tcsetattr(STDIN_FILENO, TCSANOW, &term);
}

void reset_term() {
  // Reset the terminal settings to their original values.
  termios term;
  tcgetattr(STDIN_FILENO, &term);
  term.c_lflag |= (ICANON | ECHO);
  tcsetattr(STDIN_FILENO, TCSANOW, &term);
}

// Signal handler for SIGTERM (termination signal).
void handle_sigterm(int) {
    reset_term();
}

int main() {
  int counter = 0;

  // Register signal handlers for SIGINT and SIGTERM.
  std::signal(SIGINT, handle_sigint);
  std::signal(SIGTERM, handle_sigterm);


  // Register a cleanup function to be called on normal exit.
  std::atexit([]() {
    reset_term();
  });

  while (true) {
    // Clear the console.
    fmt::print("\033[2J\033[H");

    // Print the counter.
    fmt::print("-------------\n");
    fmt::print("|  counter  |\n");
    fmt::print("-------------\n");
    fmt::print("|{:>10} |\n", counter);
    fmt::print("-------------\n");

    // Increment the counter.
    ++counter;

    // Sleep for one second.
    std::this_thread::sleep_for(std::chrono::seconds(1));

    disable_term();

    // Check for Ctrl+C input.
    if (sigint_received) {
      // Clear the flag.
      sigint_received = false;

      // Loop until a valid input is entered.
      while (true) {
        // Show the command prompt.
        fmt::print("Enter command: ");
        reset_term();
        // Read a line of input from std::cin.
        std::string command;
        std::getline(std::cin, command);

        // Process the command.
        if (command == "counter") {
          // Return to the counter display.
          break;
        } else if (command == "exit" || command == "quit") {
          // Exit the program.
          std::exit(0);
        } else {
          // Show an error message and prompt again.
          fmt::print("Invalid input. Please enter a valid command.\n");
        }
      }
    }
  }

  return 0;
}