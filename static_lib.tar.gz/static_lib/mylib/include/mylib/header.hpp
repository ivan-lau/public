#ifndef MYLIB_HEADER1_HPP
#define MYLIB_HEADER1_HPP

#include <range/v3/all.hpp>
#include <absl/container/flat_hash_map.h>

namespace mylib {
    // Define a type alias for flat_hash_map
    template<typename Key, typename Value>
    using flat_hash_map = absl::flat_hash_map<Key, Value>;

    // Define a function that uses flat_hash_map
    int get_sum() {
        // Create a flat_hash_map with ranges and values
        mylib::flat_hash_map<std::vector<int>, int> range_map = {
            {{1, 2, 3}, 2},
            {{4, 5, 6, 7}, 3},
            {{8, 9}, 1}
        };

        // Compute the sum of values times range lengths
        int sum = 0;
        for (const auto& [range, value] : range_map) {
            sum += value * ranges::distance(range);
        }
        return sum;
    }
}

#endif // MYLIB_HEADER1_HPP