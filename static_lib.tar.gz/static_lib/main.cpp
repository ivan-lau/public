#include "mylib/header.hpp"
#include <iostream>

int main() {
    // Call the get_sum function to compute the sum
    int sum = mylib::get_sum();

    // Print the result
    std::cout << "Sum: " << sum << std::endl;

    return 0;
}