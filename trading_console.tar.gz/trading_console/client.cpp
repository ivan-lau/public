#include <boost/asio.hpp>
#include <iostream>
#include <fmt/core.h>
#include <boost/program_options.hpp>
#include "order_generated.h"
#include "quote_generated.h"
#include "msg_type_generated.h"

using boost::asio::ip::tcp;
using namespace eqdwmm;
namespace po = boost::program_options;

int main(int argc, char* argv[]) {
    try {
        po::options_description desc("Allowed options");
        desc.add_options()
            ("help", "produce help message")
            ("port", po::value<int>(), "set port number");

        po::variables_map vm;
        po::store(po::parse_command_line(argc, argv, desc), vm);
        po::notify(vm);

        if (vm.count("help")) {
            std::cout << desc << std::endl;
            return 1;
        }

        if (!vm.count("port")) {
            std::cout << "Port number was not set." << std::endl;
            return 1;
        }

        auto port = vm["port"].as<int>();
        boost::asio::io_service io_service;
        tcp::resolver resolver(io_service);
        tcp::resolver::query query("localhost", std::to_string(port));
        tcp::resolver::iterator endpoint_iterator = resolver.resolve(query);
        tcp::socket socket(io_service);
        boost::asio::connect(socket, endpoint_iterator);

        while (true) {
            std::string command;
            std::cout << "Enter command: ";
            std::getline(std::cin, command);

            if (command == "orders") {
                uint32_t msg_type = MessageType_ORDER_REQUEST;
                boost::asio::write(socket, boost::asio::buffer(&msg_type, sizeof(uint32_t)));

                flatbuffers::FlatBufferBuilder builder;
                uint32_t data_size = builder.GetSize();
                boost::asio::read(socket, boost::asio::buffer(&data_size, sizeof(uint32_t)));
                std::vector<char> buffer(data_size);
                boost::asio::read(socket, boost::asio::buffer(buffer));

                auto order_response = flatbuffers::GetRoot<OrderResponse>(buffer.data());

                std::string header = fmt::format("|{:<12}|{:<15}|{:<10}|{:<10}|", "Order ID", "Instrument", "Price", "Quantity");
                std::string separator(header.length(), '-');

                fmt::print("{}\n", separator);
                fmt::print("{}\n", header);
                fmt::print("{}\n", separator);

                for (const auto order : *order_response->orders()) {
                    fmt::print("|{:<12}|{:<15}|{:<10}|{:<10}| \n", order->id(), order->instrument()->c_str(), order->price(), order->quantity());
                }

                fmt::print("{}\n", separator);
            } else if (command == "quotes") {
                uint32_t msg_type = MessageType_QUOTE_REQUEST;
                boost::asio::write(socket, boost::asio::buffer(&msg_type, sizeof(uint32_t)));

                flatbuffers::FlatBufferBuilder builder;
                uint32_t data_size = builder.GetSize();
                boost::asio::read(socket, boost::asio::buffer(&data_size, sizeof(uint32_t)));
                std::vector<char> buffer(data_size);
                boost::asio::read(socket, boost::asio::buffer(buffer));

                auto quote_response = flatbuffers::GetRoot<QuoteResponse>(buffer.data());

                std::string header = fmt::format("|{:<5}|{:<15}|{: <10}|{: <10}|{: <10}|{: <10}|", "ID", "Instrument", "Bid #", "Bid", "Ask", "Ask #");
                std::string separator(header.length(), '-');

                fmt::print("{}\n", separator);
                fmt::print("{}\n", header);
                fmt::print("{}\n", separator);

                for (const auto quote : *quote_response->quotes()) {
                    bool first = true;
                    for (const auto level : *quote->levels()) {
                        if (first) {
                            fmt::print("|{:<5}|{:<15}|{: <10}|{:<10.3f}|{:<10.3f}|{:<10}|\n",
                                    quote->id(), quote->instrument()->c_str(), level->bid_volume(),
                                    level->bid(), level->ask(), level->ask_volume());
                            first = false;
                        } else {
                            fmt::print("|{:<5}|{:<15}|{: <10}|{:<10.3f}|{:<10.3f}|{:<10}|\n",
                                    "", "", level->bid_volume(), level->bid(), level->ask(), level->ask_volume());
                        }
                    }
                    fmt::print("{}\n", separator);
                }
            } else if (command == "exit") {
                break;
            } else if (std::cin.eof()) {
                std::cout << std::endl;
                break;
            } else {
                std::cout << "Unknown command: " << command << std::endl;
            }

        }

    } catch (const boost::system::system_error& e) {
        std::cerr << "Boost system error: " << e.what() << std::endl;
    } catch (const std::exception& e) {
        std::cerr << "Standard exception: " << e.what() << std::endl;
    }

    return 0;
}