#include <boost/asio.hpp>
#include <iostream>
#include <boost/program_options.hpp>
#include "order_generated.h"
#include "quote_generated.h"
#include "msg_type_generated.h"

using boost::asio::ip::tcp;
using namespace eqdwmm;
namespace po = boost::program_options;

int main(int argc, char* argv[]) {
    try {
        po::options_description desc("Allowed options");
        desc.add_options()
            ("help", "produce help message")
            ("port", po::value<int>(), "set port number");

        po::variables_map vm;
        po::store(po::parse_command_line(argc, argv, desc), vm);
        po::notify(vm);

        if (vm.count("help")) {
            std::cout << desc << "\n";
            return 1;
        }

        if (!vm.count("port")) {
            std::cout << "Port number was not set.\n";
            return 1;
        }

        auto port = vm["port"].as<int>();

        boost::asio::io_service io_service;
        tcp::acceptor acceptor(io_service, tcp::endpoint(tcp::v4(), port));

        for (;;) {
            tcp::socket socket(io_service);
            acceptor.accept(socket);
            try {
                while (socket.is_open()) {
                    uint32_t msg_type = 0;
                    boost::asio::read(socket, boost::asio::buffer(&msg_type, sizeof(uint32_t)));

                    if (msg_type == MessageType_ORDER_REQUEST) {
                        std::cout << "Received order request" << std::endl;

                        flatbuffers::FlatBufferBuilder builder;
                        std::vector<flatbuffers::Offset<Order>> orders;
                        orders.push_back(CreateOrder(builder, 1, builder.CreateString("BUR_1015"), 4, 100));
                        orders.push_back(CreateOrder(builder, 2, builder.CreateString("BUR_0138"), 4.5, 200));
                        auto orders_vector = builder.CreateVector(orders);
                        auto order_response = CreateOrderResponse(builder, orders_vector);
                        builder.Finish(order_response);

                        uint32_t data_size = builder.GetSize();
                        boost::asio::write(socket, boost::asio::buffer(&data_size, sizeof(uint32_t)));
                        boost::asio::write(socket, boost::asio::buffer(builder.GetBufferPointer(), builder.GetSize()));
                    } else if (msg_type == MessageType_QUOTE_REQUEST) {
                        std::cout << "Received quote request" << std::endl;

                        flatbuffers::FlatBufferBuilder builder;
                        std::vector<flatbuffers::Offset<Level>> levels1;
                        levels1.push_back(CreateLevel(builder, 7.710, 7.720, 8000, 3000));
                        levels1.push_back(CreateLevel(builder, 7.700, 7.730, 12400, 1000));

                        std::vector<flatbuffers::Offset<Level>> levels2;
                        levels2.push_back(CreateLevel(builder, 7.690, NAN, 10000, 0));
                        levels2.push_back(CreateLevel(builder, 7.680, NAN, 1000, 0));
                        levels2.push_back(CreateLevel(builder, 7.600, NAN, 500, 0));

                        std::vector<flatbuffers::Offset<Quote>> quotes;
                        quotes.push_back(CreateQuote(builder, 1, builder.CreateString("BUR_1015"), builder.CreateVector(levels1)));
                        quotes.push_back(CreateQuote(builder, 2, builder.CreateString("BUR_1017"), builder.CreateVector(levels2)));

                        auto quotes_vector = builder.CreateVector(quotes);
                        auto quote_response = CreateQuoteResponse(builder, quotes_vector);
                        builder.Finish(quote_response);

                        uint32_t data_size = builder.GetSize();
                        boost::asio::write(socket, boost::asio::buffer(&data_size, sizeof(uint32_t)));
                        boost::asio::write(socket, boost::asio::buffer(builder.GetBufferPointer(), builder.GetSize()));
                    }
                }
            } catch (std::exception& e) {
                std::cerr << "Client disconnected: " << std::endl;
            }
        }
    } catch (const std::exception& e) {
        std::cerr << "Server error: " << e.what() << std::endl;
    }
    return 0;
}