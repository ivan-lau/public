from flask import Flask, request, render_template

# globals
app = Flask(__name__)

@app.route("/")
def home():
    return render_template("calendar.html")

@app.route('/data')
def return_data():
    start_date = request.args.get('start', '')
    end_date = request.args.get('end', '')
    with open("events.json", "r") as input_data:
        return input_data.read()

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5000, debug=False, use_reloader=False)
