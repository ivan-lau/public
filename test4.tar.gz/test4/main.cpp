#include <iostream>
#include <dlfcn.h>

int main() {
    // Load the first shared library
    void* handle1 = dlmopen(LM_ID_NEWLM, "libmylib.so", RTLD_NOW | RTLD_LOCAL);

    if (!handle1) {
        std::cerr << "Error loading shared library: " << dlerror() << std::endl;
        return 1;
    }

    // Get a pointer to the increment() function
    typedef void (*increment_t)();
    increment_t increment1 = (increment_t) dlsym(handle1, "increment");

    if (!increment1) {
        std::cerr << "Error getting symbol: " << dlerror() << std::endl;
        dlclose(handle1);
        return 1;
    }

    // Call the increment() function in the first shared library
    increment1();

    // Get a pointer to the get_count() function
    typedef int (*get_count_t)();
    get_count_t get_count1 = (get_count_t) dlsym(handle1, "get_count");

    if (!get_count1) {
        std::cerr << "Error getting symbol: " << dlerror() << std::endl;
        dlclose(handle1);
        return 1;
    }

    // Get the current count from the first shared library
    int count1 = get_count1();
    std::cout << "Count in the first shared library: " << count1 << std::endl;

    // Unload the first shared library
    dlclose(handle1);

    // Load the second shared library
    void* handle2 = dlmopen(LM_ID_NEWLM, "libmylib.so", RTLD_NOW | RTLD_LOCAL);

    if (!handle2) {
        std::cerr << "Error loading shared library: " << dlerror() << std::endl;
        return 1;
    }

    // Get a pointer to the increment() function
    increment_t increment2 = (increment_t) dlsym(handle2, "increment");

    if (!increment2) {
        std::cerr << "Error getting symbol: " << dlerror() << std::endl;
        dlclose(handle2);
        return 1;
    }

    // Call the increment() function in the second shared library
    increment2();

    // Get a pointer to the get_count() function
    get_count_t get_count2 = (get_count_t) dlsym(handle2, "get_count");

    if (!get_count2) {
        std::cerr << "Error getting symbol: " << dlerror() << std::endl;
        dlclose(handle2);
        return 1;
    }

    // Get the current count from the second shared library
    int count2 = get_count2();
    std::cout << "Count in the second shared library: " << count2 << std::endl;

    // Unload the second shared library
    dlclose(handle2);

    return 0;
}