#include <iostream>

static int count = 0;

extern "C" void hello() {
    std::cout << "Hello from the shared library!\n";
}

extern "C" int add(int a, int b) {
    return a + b;
}

extern "C" void increment() {
    count++;
}

extern "C" int get_count() {
    return count;
}