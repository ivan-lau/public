#ifndef ENGINE_ENGINE_HPP
#define ENGINE_ENGINE_HPP

#include <cassert>

#include "engine/engine_export.h"

int ENGINE_EXPORT main();

namespace engine
{
template<class T>
struct application_registrar;

class application;

// std::unique_ptr has no dll interface, so we implement our own
class ENGINE_EXPORT application_ptr
{
    application* m_ptr;
public:
    application_ptr(application* app = nullptr) noexcept
        : m_ptr(app)
    {
    }

    ~application_ptr();

    application_ptr(application_ptr&& other) noexcept
        : m_ptr(other.m_ptr)
    {
        other.m_ptr = nullptr;
    }

    application_ptr& operator=(application_ptr&& other) noexcept;

    explicit operator bool() const noexcept
    {
        return m_ptr != nullptr;
    }

    application* operator->() const noexcept
    {
        assert(m_ptr != nullptr);
        return m_ptr;
    }

    application& operator*() const noexcept
    {
        assert(m_ptr != nullptr);
        return *m_ptr;
    }

};

class ENGINE_EXPORT application
{
    template<class T>
    friend struct application_registrar;

    friend int ::main();

    static application_ptr s_applicationInstance;
public:
    virtual ~application() = 0;

    virtual void DoSomething() = 0;

    static application& instance() noexcept
    {
        [[maybe_unused]] bool const applicationAlreadyRegistered = static_cast<bool>(application::s_applicationInstance);
        assert(applicationAlreadyRegistered);
        return *s_applicationInstance;
    }
};

template<class T>
struct application_registrar
{
    application_registrar()
    {
        [[maybe_unused]] bool const applicationAlreadyRegistered = static_cast<bool>(application::s_applicationInstance);
        assert(!applicationAlreadyRegistered);
        try
        {
            application::s_applicationInstance = application_ptr(new T());
        }
        catch (...)
        {
            assert(!"an exception was thrown initializing the application");
            throw;
        }
    }
};

inline application_ptr::~application_ptr()
{
    delete m_ptr;
}

inline application_ptr& application_ptr::operator=(application_ptr&& other) noexcept
{
    delete m_ptr;
    m_ptr = other.m_ptr;
    other.m_ptr = nullptr;
    return *this;
}

} // namespace engine

/**
 * macro for registering the game
 */
#define ENGINE_GAME(type)                                                           \
namespace EngineGameRegistrationImpl                                                \
{                                                                                   \
static ::engine::application_registrar<type> g_gameRegistrator##type##__LINE__ ;    \
}

#endif // ENGINE_ENGINE_HPP