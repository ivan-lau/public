#include <iostream>

#include "engine/engine.hpp"

class my_game : public engine::application
{
public:
    void DoSomething() override
    {
        std::cout << "Hello World!\n";
    }
};

ENGINE_GAME(my_game);