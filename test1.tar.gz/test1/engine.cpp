#include "engine/engine.hpp"

namespace engine
{
    application_ptr application::s_applicationInstance;

    application::~application() {}
}

int main()
{
    engine::application::instance().DoSomething();
    return 0;
}