#pragma once

#include <chrono>
#include <thread>
#include <random>
#include <absl/container/flat_hash_map.h>

namespace stream {
    template <typename T>
    class Stream {
    public:
        struct IHandler {
            void onUpdate(int num1, int value) {
                static_cast<T*>(this)->HandleUpdate(num1, value);
            }
        };

        Stream(IHandler& handler) : m_handler(handler) {}

        void Open() {
            while (true) {
                int num1 = GenerateRandomNumber();
                int value = m_data[num1];
                m_handler.onUpdate(num1, value);
                std::this_thread::sleep_for(std::chrono::seconds(1));
            }
        }

    private:
    int GenerateRandomNumber() {
        static std::random_device rd;
        static std::mt19937 gen(rd());
        static std::uniform_int_distribution<> dis(1, 3);
        return dis(gen);
    }

        IHandler &m_handler;
        absl::flat_hash_map<int, int> m_data{{1, 100}, {2, 200}, {3, 300}};
    };

}