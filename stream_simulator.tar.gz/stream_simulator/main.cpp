#include <ivan/Stream.hpp>
#include <iostream>

class Subscriber : public stream::Stream<Subscriber>::IHandler {
public:
    Subscriber() : m_stream(*this) {} 
    void Start() {
        m_stream.Open();
    }

    void HandleUpdate(int num1, int value) {
        std::cout << "num1: [" << num1 << "] value ["<<value<<"]" << std::endl;
    }
private:
    stream::Stream<Subscriber> m_stream;
};

int main() {

    Subscriber s;
    s.Start();
    return 0;
}